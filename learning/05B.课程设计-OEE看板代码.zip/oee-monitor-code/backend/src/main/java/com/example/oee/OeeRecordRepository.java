
// 文件: src/main/java/com/example/oee/OeeRecordRepository.java
package com.example.oee;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface OeeRecordRepository extends JpaRepository<OeeRecord, Long> {
    List<OeeRecord> findTop100ByOrderByTimestampDesc();
}
