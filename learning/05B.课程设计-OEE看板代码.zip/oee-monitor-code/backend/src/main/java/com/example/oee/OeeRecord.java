
// 文件: src/main/java/com/example/oee/OeeRecord.java
package com.example.oee;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import lombok.Data;

@Entity
@Data
public class OeeRecord {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private LocalDateTime timestamp;
    private String deviceId;
    private String status;
    private int output;
    private int goodOutput;

}
