
// 文件: src/main/java/com/example/oee/DataGenerator.java
package com.example.oee;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import jakarta.annotation.PostConstruct;
import java.time.LocalDateTime;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

@Component
public class DataGenerator {

    @Autowired
    private OeeRecordRepository repository;

    @PostConstruct
    public void startGenerating() {
        new Timer().schedule(new TimerTask() {
            int output = 0;
            int goodOutput = 0;
            Random random = new Random();

            @Override
            public void run() {
                output += random.nextInt(3);
                goodOutput = output - random.nextInt(2);
                OeeRecord record = new OeeRecord();
                record.setTimestamp(LocalDateTime.now());
                record.setDeviceId("CNC-001");

                // 根据90%概率设置"运行"，10%概率设置"等待"或"故障"
                int statusChance = random.nextInt(100);
                if (statusChance < 90) {
                    record.setStatus("运行");
                } else {
                    record.setStatus(random.nextBoolean() ? "等待" : "故障");
                }

                record.setOutput(output);
                record.setGoodOutput(goodOutput);
                repository.save(record);
            }
        }, 0, 5000);
    }
}
