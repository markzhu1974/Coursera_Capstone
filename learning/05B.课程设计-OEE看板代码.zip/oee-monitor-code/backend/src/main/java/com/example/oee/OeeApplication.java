
// 文件: src/main/java/com/example/oee/OeeApplication.java
package com.example.oee;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OeeApplication {
    public static void main(String[] args) {
        SpringApplication.run(OeeApplication.class, args);
    }
}
