import React, { useEffect, useState } from 'react';
import { CircularProgressbar, buildStyles } from 'react-circular-progressbar';
import 'react-circular-progressbar/dist/styles.css';
import './App.css';

const Gauge = ({ value, text }) => (
  <div style={{ width: 100, height: 100 }}>
    <CircularProgressbar
      value={value * 100}
      text={`${(value * 100).toFixed(1)}%`}
      styles={buildStyles({
        textSize: '16px',
        pathColor: `#3e98c7`,
        textColor: '#000',
      })}
    />
    <div>{text}</div>
  </div>
);

const App = () => {
  const [data, setData] = useState([]);
  const [metrics, setMetrics] = useState({ availability: 0, performance: 0, quality: 0, oee: 0 });

  useEffect(() => {
    const interval = setInterval(() => {
      fetch('http://localhost:8080/api/data')
        .then(res => res.json())
        .then(json => {
          setData(json);
          calculateOEE(json);
        });
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  const calculateOEE = (records) => {
    const recent = records.slice(-60);
    if (recent.length < 2) return;

    const runTime = recent.filter(d => d.status === '运行').length * 5;
    const plannedTime = recent.length * 5;
    const availability = runTime / plannedTime;

    const outputDelta = recent[0].output - recent[recent.length - 1].output;
    const speed = 80;
    const performance = outputDelta / speed;

    const goodOutputDelta = recent[0].goodOutput - recent[recent.length - 1].goodOutput;

    const quality = goodOutputDelta / outputDelta;

    const oee = availability * performance * quality;

    setMetrics({ availability, performance, quality, oee });
  };

  return (
    <div className="App">
      <h2 className="center-text">数控设备 OEE 实时监控</h2>
      <div className="gauges">
        <Gauge value={metrics.availability} text="Availability" />
        <Gauge value={metrics.performance} text="Performance" />
        <Gauge value={metrics.quality} text="Quality" />
      </div>
      <h3 className="center-text">OEE 总值: {(metrics.oee * 100).toFixed(2)}%</h3>
    </div>

  );
};

export default App;