<template>
  <div>
    <h1>数控设备信息管理系统</h1>
    <nav>
      <router-link to="/devices">设备管理</router-link> |
      <router-link to="/logs">运行记录</router-link> |
      <router-link to="/repairs">维修记录</router-link>
    </nav>
    <router-view></router-view>
  </div>
</template>

<script setup>
import { RouterLink, RouterView } from 'vue-router'
</script>

<style>
nav {
  padding: 1rem;
  background: #f0f0f0;
  margin-bottom: 1rem;
}
nav a {
  margin: 0 0.5rem;
  text-decoration: none;
  color: #333;
}
nav a.router-link-active {
  color: #42b983;
  font-weight: bold;
}
</style>