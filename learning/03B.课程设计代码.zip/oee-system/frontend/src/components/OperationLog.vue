<template>
  <div>
    <h2>运行记录</h2>
    <button @click="showAddDialog = true">添加记录</button>
    
    <table>
      <thead>
        <tr>
          <th>记录ID</th>
          <th>设备编号</th>
          <th>日期</th>
          <th>操作员</th>
          <th>运行时间(小时)</th>
          <th>加工件数</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="log in logs" :key="log.log_id">
          <td>{{ log.log_id }}</td>
          <td>{{ log.device_id }}</td>
          <td>{{ log.date }}</td>
          <td>{{ log.operator }}</td>
          <td>{{ log.runtime }}</td>
          <td>{{ log.output }}</td>
        </tr>
      </tbody>
    </table>

    <!-- 添加记录对话框 -->
    <dialog v-if="showAddDialog">
      <h3>添加运行记录</h3>
      <form @submit.prevent="submitLog">
        <label>设备编号: 
          <select v-model="logForm.device_id" required>
            <option v-for="device in devices" :value="device.device_id">{{ device.device_id }}</option>
          </select>
        </label>
        <label>日期: <input type="date" v-model="logForm.date" required></label>
        <label>操作员: <input v-model="logForm.operator" required></label>
        <label>运行时间(小时): <input type="number" step="0.1" v-model="logForm.runtime" required></label>
        <label>加工件数: <input type="number" v-model="logForm.output" required></label>
        <button type="submit">保存</button>
        <button type="button" @click="showAddDialog = false">取消</button>
      </form>
    </dialog>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import axios from 'axios'

const logs = ref([])
const devices = ref([])
const showAddDialog = ref(false)
const logForm = ref({
  device_id: '',
  date: '',
  operator: '',
  runtime: 0,
  output: 0
})

const fetchLogs = async () => {
  const response = await axios.get('http://localhost:5000/api/logs')
  logs.value = response.data
}

const fetchDevices = async () => {
  const response = await axios.get('http://localhost:5000/api/devices')
  devices.value = response.data
}

const submitLog = async () => {
  await axios.post('http://localhost:5000/api/logs', logForm.value)
  showAddDialog.value = false
  fetchLogs()
}

onMounted(() => {
  fetchLogs()
  fetchDevices()
})
</script>