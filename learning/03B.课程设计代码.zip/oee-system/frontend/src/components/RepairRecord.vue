<template>
  <div>
    <h2>维修记录</h2>
    <button @click="showAddDialog = true">添加记录</button>
    
    <table>
      <thead>
        <tr>
          <th>维修单号</th>
          <th>设备编号</th>
          <th>故障日期</th>
          <th>故障描述</th>
          <th>维修费用</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="repair in repairs" :key="repair.repair_id">
          <td>{{ repair.repair_id }}</td>
          <td>{{ repair.device_id }}</td>
          <td>{{ repair.fault_date }}</td>
          <td>{{ repair.description }}</td>
          <td>{{ repair.cost }}</td>
        </tr>
      </tbody>
    </table>

    <!-- 添加记录对话框 -->
    <dialog v-if="showAddDialog">
      <h3>添加维修记录</h3>
      <form @submit.prevent="submitRepair">
        <label>设备编号: 
          <select v-model="repairForm.device_id" required>
            <option v-for="device in devices" :value="device.device_id">{{ device.device_id }}</option>
          </select>
        </label>
        <label>故障日期: <input type="date" v-model="repairForm.fault_date" required></label>
        <label>故障描述: <textarea v-model="repairForm.description" required></textarea></label>
        <label>解决方案: <textarea v-model="repairForm.solution" required></textarea></label>
        <label>维修费用: <input type="number" step="0.01" v-model="repairForm.cost" required></label>
        <button type="submit">保存</button>
        <button type="button" @click="showAddDialog = false">取消</button>
      </form>
    </dialog>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import axios from 'axios'

const repairs = ref([])
const devices = ref([])
const showAddDialog = ref(false)
const repairForm = ref({
  device_id: '',
  fault_date: '',
  description: '',
  solution: '',
  cost: 0
})

const fetchRepairs = async () => {
  const response = await axios.get('http://localhost:5000/api/repairs')
  repairs.value = response.data
}

const fetchDevices = async () => {
  const response = await axios.get('http://localhost:5000/api/devices')
  devices.value = response.data
}

const submitRepair = async () => {
  await axios.post('http://localhost:5000/api/repairs', repairForm.value)
  showAddDialog.value = false
  fetchRepairs()
}

onMounted(() => {
  fetchRepairs()
  fetchDevices()
})
</script>