<template>
  <div>
    <h2>设备列表</h2>
    <button @click="showAddDialog = true; editing = false; resetForm()">添加设备</button>
    
    <table>
      <thead>
        <tr>
          <th>设备编号</th>
          <th>类型</th>
          <th>型号</th>
          <th>状态</th>
          <th>购买日期</th>
          <th>操作</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="device in devices" :key="device.device_id">
          <td>{{ device.device_id }}</td>
          <td>{{ device.type }}</td>
          <td>{{ device.model }}</td>
          <td>{{ device.status }}</td>
          <td>{{ device.purchase_date }}</td>
          <td>
            <button @click="editDevice(device)">编辑</button>
            <button @click="deleteDevice(device.device_id)">删除</button>
          </td>
        </tr>
      </tbody>
    </table>

    <!-- 自定义 div 对话框 -->
    <div v-if="showAddDialog" class="dialog-overlay">
      <div class="dialog">
        <h3>{{ editing ? '编辑设备' : '添加设备' }}</h3>
        <form @submit.prevent="submitDevice">
          <label>设备编号: <input v-model="form.device_id" :readonly="editing" required></label>
          <label>类型: <input v-model="form.type" required></label>
          <label>型号: <input v-model="form.model" required></label>
          <label>规格: <textarea v-model="form.spec"></textarea></label>
          <label>购买日期: <input type="date" v-model="form.purchase_date" required></label>
          <label>状态: 
            <select v-model="form.status">
              <option value="运行中">运行中</option>
              <option value="停机">停机</option>
              <option value="维修中">维修中</option>
            </select>
          </label>
          <button type="submit" :disabled="isSaving">
            {{ isSaving ? '保存中...' : '保存' }}
          </button>
          <button type="button" @click="closeDialog" :disabled="isSaving">取消</button>
        </form>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import axios from 'axios'

const devices = ref([])
const showAddDialog = ref(false)
const editing = ref(false)
const isSaving = ref(false) // loading 状态
const form = ref({
  device_id: '',
  type: '',
  model: '',
  spec: '',
  purchase_date: '',
  status: '运行中'
})

// 重置表单
const resetForm = () => {
  form.value = {
    device_id: '',
    type: '',
    model: '',
    spec: '',
    purchase_date: '',
    status: '运行中'
  }
}

// 关闭dialog
const closeDialog = () => {
  showAddDialog.value = false
  resetForm()
  editing.value = false
}

const fetchDevices = async () => {
  const response = await axios.get('http://localhost:5000/api/devices')
  devices.value = response.data
}

const editDevice = (device) => {
  editing.value = true
  form.value = { ...device }
  showAddDialog.value = true
}

const submitDevice = async () => {
  isSaving.value = true // 开始loading
  try {
    if (editing.value) {
      await axios.put(`http://localhost:5000/api/devices/${form.value.device_id}`, form.value)
    } else {
      await axios.post('http://localhost:5000/api/devices', form.value)
    }
    await fetchDevices()
    closeDialog()
  } catch (error) {
    console.error("提交设备失败：", error)
    alert("保存失败，请重试！")
    closeDialog()
  } finally {
    isSaving.value = false // loading结束
    closeDialog()
  }
}

const deleteDevice = async (id) => {
  if (confirm('确定删除此设备吗？')) {
    await axios.delete(`http://localhost:5000/api/devices/${id}`)
    fetchDevices()
  }
}

onMounted(() => {
  fetchDevices()
})
</script>

<style scoped>
table {
  width: 100%;
  border-collapse: collapse;
}
th, td {
  border: 1px solid #ddd;
  padding: 8px;
}
tr:nth-child(even) {
  background-color: #f2f2f2;
}

.dialog-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0,0,0,0.4);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 999;
}

.dialog {
  background: white;
  padding: 20px;
  border-radius: 8px;
  width: 400px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.3);
}

.dialog h3 {
  margin-top: 0;
}

.dialog label {
  display: block;
  margin: 10px 0;
}

.dialog input,
.dialog textarea,
.dialog select {
  width: 100%;
  padding: 6px;
  box-sizing: border-box;
}

button[disabled] {
  opacity: 0.6;
  cursor: not-allowed;
}
</style>
