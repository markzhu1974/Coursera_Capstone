import { createRouter, createWebHistory } from 'vue-router'
import DeviceList from './components/DeviceList.vue'
import OperationLog from './components/OperationLog.vue'
import RepairRecord from './components/RepairRecord.vue'

const routes = [
  { path: '/', redirect: '/devices' },
  { path: '/devices', component: DeviceList },
  { path: '/logs', component: OperationLog },
  { path: '/repairs', component: RepairRecord }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

export default router