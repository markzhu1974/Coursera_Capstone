from datetime import date
from flask import Flask, jsonify, request
from flask_cors import CORS
from models import db, Device, OperationLog, RepairRecord
import os

app = Flask(__name__)
CORS(app)

# 配置数据库
basedir = os.path.abspath(os.path.dirname(__file__))
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(basedir, 'data/device.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db.init_app(app)

# 初始化数据库
with app.app_context():
    db.create_all()
    if not Device.query.first():  # 如果数据库为空
        print("Initializing database with test data...")
        test_devices = [ 
            Device(   
                device_id="CNC-001",
                type="数控车床",
                model="CK6140",
                spec="最大转速2000rpm",
                purchase_date="2023-01-02",
                status="运行中"
            ),
            Device(   
                device_id="CNC-002",
                type="数控车床",
                model="CK6140",
                spec="最大转速2000rpm",
                purchase_date="2023-01-02",
                status="运行中"
            ),
            Device(
                device_id="CNC-003",
                type="数控铣床",
                model="XK7124",
                spec="最大转速3000rpm",
                purchase_date="2023-02-15",
                status="维修中"
            ),
            Device(
                device_id="CNC-004",
                type="数控磨床",
                model="MG1432",
                spec="最大转速1500rpm",
                purchase_date="2023-03-10",
                status="闲置"
            ),
            Device(
                device_id="CNC-005",
                type="数控电火花机",
                model="EDM-500",
                spec="最大加工深度100mm",
                purchase_date="2023-04-20",
                status="运行中"
            ),
            Device(
                device_id="CNC-006",
                type="数控激光切割机",
                model="LaserCut-3000",
                spec="最大切割厚度20mm",
                purchase_date="2023-05-05",
                status="运行中"
            ),
            Device(
                device_id="CNC-007",
                type="数控折弯机",
                model="Bending-100T",
                spec="最大折弯长度3000mm",
                purchase_date="2023-06-18",
                status="维修中"
            ),
            Device(
                device_id="CNC-008",
                type="数控冲床",
                model="Punch-200T",
                spec="最大冲压力200吨",
                purchase_date="2023-07-22",
                status="运行中"
            ),
            Device(
                device_id="CNC-009",
                type="数控火焰切割机",
                model="FlameCut-2000",
                spec="最大切割厚度50mm",
                purchase_date="2023-08-30",
                status="闲置"
            ),
            Device(
                device_id="CNC-010",
                type="数控水刀切割机",
                model="WaterJet-5000",
                spec="最大切割厚度100mm",
                purchase_date="2023-09-12",
                status="运行中"
            )
        ]
        db.session.bulk_save_objects(test_devices)
        db.session.commit()

# 设备管理接口
@app.route('/api/devices', methods=['GET', 'POST'])
def devices():
    if request.method == 'GET':
        devices = Device.query.all()
        return jsonify([d.to_dict() for d in devices])
    else:
        data = request.get_json()
        device = Device(
            device_id=data['device_id'],
            type=data['type'],
            model=data['model'],
            spec=data['spec'],
            purchase_date=data['purchase_date'],
            status=data['status']
        )
        db.session.add(device)
        db.session.commit()
        return jsonify(device.to_dict())

@app.route('/api/devices/<device_id>', methods=['GET', 'PUT', 'DELETE'])
def device(device_id):
    device = Device.query.get_or_404(device_id)
    if request.method == 'GET':
        return jsonify(device.to_dict())
    elif request.method == 'PUT':
        data = request.get_json()
        device.type = data['type']
        device.model = data['model']
        device.spec = data['spec']
        device.purchase_date = data['purchase_date']
        device.status = data['status']
        db.session.commit()
        return jsonify(device.to_dict())
    else:
        db.session.delete(device)
        db.session.commit()
        return jsonify({'message': 'Device deleted'})

# 运行记录接口
@app.route('/api/logs', methods=['GET', 'POST'])
def logs():
    if request.method == 'GET':
        logs = OperationLog.query.all()
        return jsonify([l.to_dict() for l in logs])
    else:
        data = request.get_json()
        log = OperationLog(
            device_id=data['device_id'],
            date=data['date'],
            operator=data['operator'],
            runtime=data['runtime'],
            output=data['output']
        )
        db.session.add(log)
        db.session.commit()
        return jsonify(log.to_dict())

# 维修记录接口
@app.route('/api/repairs', methods=['GET', 'POST'])
def repairs():
    if request.method == 'GET':
        repairs = RepairRecord.query.all()
        return jsonify([r.to_dict() for r in repairs])
    else:
        data = request.get_json()
        repair = RepairRecord(
            device_id=data['device_id'],
            fault_date=data['fault_date'],
            description=data['description'],
            solution=data['solution'],
            cost=data['cost']
        )
        db.session.add(repair)
        db.session.commit()
        return jsonify(repair.to_dict())

if __name__ == '__main__':
    app.run(debug=True)