from flask_sqlalchemy import SQLAlchemy
from datetime import date, datetime


db = SQLAlchemy()

class Device(db.Model):
    __tablename__ = 'devices'
    
    device_id = db.Column(db.String(20), primary_key=True)
    type = db.Column(db.String(50))
    model = db.Column(db.String(50))
    spec = db.Column(db.Text)
    purchase_date = db.Column(db.Text)
    status = db.Column(db.String(20))
    
    def to_dict(self):
        return {
            'device_id': self.device_id,
            'type': self.type,
            'model': self.model,
            'spec': self.spec,
            'purchase_date': self.purchase_date,
            'status': self.status
        }

class OperationLog(db.Model):
    __tablename__ = 'operation_logs'
    
    log_id = db.Column(db.Integer, primary_key=True)
    device_id = db.Column(db.String(20), db.ForeignKey('devices.device_id'))
    date = db.Column(db.Date)
    operator = db.Column(db.String(50))
    runtime = db.Column(db.Float)
    output = db.Column(db.Integer)
    
    def to_dict(self):
        return {
            'log_id': self.log_id,
            'device_id': self.device_id,
            'date': str(self.date),
            'operator': self.operator,
            'runtime': self.runtime,
            'output': self.output
        }

class RepairRecord(db.Model):
    __tablename__ = 'repair_records'
    
    repair_id = db.Column(db.Integer, primary_key=True)
    device_id = db.Column(db.String(20), db.ForeignKey('devices.device_id'))
    fault_date = db.Column(db.Date)
    description = db.Column(db.Text)
    solution = db.Column(db.Text)
    cost = db.Column(db.Float)
    
    def to_dict(self):
        return {
            'repair_id': self.repair_id,
            'device_id': self.device_id,
            'fault_date': str(self.fault_date),
            'description': self.description,
            'solution': self.solution,
            'cost': self.cost
        }