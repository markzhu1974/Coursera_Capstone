# 数控设备信息管理系统

## 项目概述
一个基于Vue3和Flask的数控设备管理系统，包含设备管理、运行记录和维修记录功能。

## 技术栈
- 前端：Vue3 + Vue Router + Axios
- 后端：Flask + SQLAlchemy
- 数据库：SQLite

## 安装与运行

### 后端

cd backend
pip install -r requirements.txt
python app.py

### 前端

cd frontend
npm install
npm run dev


## 功能
1. 设备信息管理（CRUD）
2. 设备运行记录
3. 设备维修记录
