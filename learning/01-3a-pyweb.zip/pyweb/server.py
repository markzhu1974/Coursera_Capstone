from http.server import SimpleHTTPRequestHandler, HTTPServer
import os
import urllib.parse

class StaticFileHandler(SimpleHTTPRequestHandler):
  def __init__(self, *args, **kwargs):
      super().__init__(*args, directory='static', **kwargs)

  def do_GET(self):
      if self.path == '/':
          self.path = '/index.html'

      file_path = os.path.join('static', self.path[1:])
      if not os.path.exists(file_path):
          self.send_error(404, "File not found")
          return

      return super().do_GET()

  def do_POST(self):
      if self.path == '/submit':
          content_length = int(self.headers['Content-Length'])
          post_data = self.rfile.read(content_length).decode('utf-8')

          parsed_data = urllib.parse.parse_qs(post_data)
          name = parsed_data.get('name', [''])[0]
          email = parsed_data.get('email', [''])[0]

          try:
              with open('static/response.html', 'r', encoding='utf-8') as file:
                  response_template = file.read()

              response = response_template.format(name=name, email=email)

              self.send_response(200)
              self.send_header('Content-type', 'text/html')
              self.end_headers()
              self.wfile.write(response.encode('utf-8'))
          except FileNotFoundError:
              self.send_error(404, "File not found")
      else:
          self.send_error(404, "Invalid path")

def run(server_class=HTTPServer, handler_class=StaticFileHandler, port=8000):
  if not os.path.exists('static'):
      os.makedirs('static')

  server_address = ('', port)
  httpd = server_class(server_address, handler_class)
  print(f'Serving static files from http://localhost:{port}')
  httpd.serve_forever()

if __name__ == '__main__':
  run()